
// Settings.
export const Settings = {
	production: "{{PRODUCTION}}" as any as boolean,
}